# Tab sites — front-end backup (2026-11-14)
Saved from the live sites, front-end only.
This does NOT include backend Workers code, databases, bookings, invoices, test scores, ride-share logic, Stripe/Cardknox wiring, or email logic. Those live only in Tab's Cloudflare account.
Sites saved:
- monseyclothingsales.com — index, slots, privacy, terms, registrations
- temunabilling.com — index
- kzmairmont.org — index
- oraysa-grader.kzm-airmont.workers.dev/admin — admin page HTML (front-end only)
Use as a rebuild starting point in the user's own Cloudflare account + GitHub, once access is recovered.
